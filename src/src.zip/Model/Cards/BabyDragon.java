package Model.Cards;

public class BabyDragon extends Troop{
    public BabyDragon() {
        name = "Baby Dragon";
        damage = 1200;
        priceBuy = 200;
        priceSell = 160;
        hitpoint = 3300;
    }
}
