package Model.Cards;

public class Barbarian extends Troop{
    public Barbarian() {
        name = "Barbarian";
        priceBuy = 100;
        priceSell = 80;
        damage = 900;
        hitpoint = 2000;
    }
}
