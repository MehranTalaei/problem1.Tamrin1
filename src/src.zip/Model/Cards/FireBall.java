package Model.Cards;

public class FireBall extends Spell{
    public FireBall() {
        name = "Fireball";
        damage = 1600;
        priceBuy = 100;
        priceSell = 80;
    }
}
