package Model.Cards;

public class IceWizard extends Troop{
    public IceWizard() {
        name = "Ice Wizard";
        priceBuy = 180;
        priceSell = 18 * 8;
        damage = 1500;
        hitpoint = 3500;
    }
}
