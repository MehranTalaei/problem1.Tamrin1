package Model.Cards;

abstract public class Spell extends Card{
}
