package Model;

public enum PlayerSide {
    Host,Guest;
}
